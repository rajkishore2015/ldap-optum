package com.in28minutes.fullstack.springboot.react.basic.authentication.springbootreactbasicauthloginlogout;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class SpringBootReactBasicAuthLoginLogoutApplicationTests {

	//	@Test
	public void contextLoads() {
	}

}
